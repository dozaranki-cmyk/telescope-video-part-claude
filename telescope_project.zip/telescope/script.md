# The Telescope That Needed Glasses

Audience: curious adults in the United States. Format: 9:16 short, target ~60 seconds. Visual style: flat 2D cartoon characters in a colorful, busy 3D world; moving camera; one-word captions.

## Approved narration and shot plan

| Shot | Spoken text | Visual action |
|---|---|---|
| launch | In nineteen ninety, NASA launched Hubble into space. Its first pictures looked like potato photos. | Shuttle lifts off; a comically blurry first-light starfield appears on a monitor. |
| blur | Hubble was built to see the universe in stunning detail. Instead, stars looked like fuzzy blobs. | Control room scientists compare a sharp star icon with Hubble's smeared image. |
| investigate | Scientists investigated. The problem wasn't the cameras or computers. | Busy optical lab; technicians inspect camera, cables, and consoles. |
| mirror | Hubble's primary mirror had the wrong shape. Its outer edge was slightly too flat. | Giant mirror close-up; the rim is subtly flatter than the ideal curve. |
| science | You see, light must meet at one point to make a sharp image. Hubble's mirror sent rays to different places. | Animated rays converge to different focal points, then a clean ideal focus is shown. |
| orbit | The error was tiny. But Hubble was hundreds of miles above Earth. Its mirror couldn't come home. | Hubble floats above Earth; tiny flaw highlighted against enormous planet. |
| plan | So engineers planned something wild: leave the mirror alone, and correct the light instead. | Engineers in a control lab design a compact relay-mirror assembly. |
| shuttle | In December nineteen ninety-three, astronauts flew to Hubble aboard the shuttle Endeavour. | Endeavour approaches Hubble in orbit; Earth and shuttle bay fill the frame. |
| repair | During five spacewalks, they installed new equipment, including a device called COSTAR. | Astronauts secure a refrigerator-sized COSTAR unit in Hubble's instrument bay. |
| glasses | It used tiny corrective mirrors like eyeglasses, redirecting light so instruments could focus. | COSTAR mirror arms deploy; a glasses motif overlays the light path. |
| comeback | A new camera had its own corrective optics. Hubble's images finally became sharp. | WFPC2 camera slides into place; blurred galaxy becomes crisp. |
| twist | Humanity built a telescope to see across the universe. Then had to give it glasses. | Hubble wears oversized cartoon glasses; camera pushes into a starry cosmic vista. |

## Fact map and sources
- Hubble launched April 24, 1990; first images were blurry because its primary mirror had spherical aberration: NASA, [The Camera That Saved Hubble](https://science.nasa.gov/missions/hubble/the-camera-that-saved-hubble/) and [NASA History: 30 Years Ago](https://www.nasa.gov/history/30-years-ago-hubble-launched-to-unlock-the-secrets-of-the-universe/).
- The mirror's outer edge was too flat by about 2.2 microns; NASA describes the optical consequences and correction: [Hubble's Mirror Flaw](https://science.nasa.gov/mission/hubble/observatory/design/optics/hubbles-mirror-flaw/) and ESA/Hubble, [History: The Spherical Aberration Problem](https://esahubble.org/about/history/aberration_problem/).
- COSTAR corrected three of the five original instruments; WFPC2 had its own built-in corrective optics: NASA [Servicing Mission 1](https://science.nasa.gov/mission/hubble/observatory/missions-to-hubble/servicing-mission-1/) and ESA/Hubble [Servicing Mission 1](https://esahubble.org/about/history/servicing_mission_1/).
- The first servicing mission was STS-61 aboard Endeavour in December 1993 and included five spacewalks: NASA [NASA History: 30 Years Ago](https://www.nasa.gov/history/30-years-ago-hubble-launched-to-unlock-the-secrets-of-the-universe/) and ESA/Hubble [Servicing Mission 1](https://esahubble.org/about/history/servicing_mission_1/).

## Dramatisation and omissions
- The animated scientists, engineers, and astronaut staging are illustrative, not portrayals of named historical people or exact documented moments.
- “Potato photos” is a comedic comparison, not a historical quote.
- The script simplifies spherical aberration as rays reaching different focal points. It does not claim the telescope was completely useless; Hubble still produced some useful science before correction.
- COSTAR and WFPC2 are distinguished: COSTAR corrected light for three existing instruments; WFPC2 contained its own corrective optics.
- No invented dialogue or quotations are used.

## Wording to watch
- Pronounce Hubble as “HUB-uhl”; COSTAR as “KOH-star”; Endeavour as “en-DEV-er”; WFPC2 is not spoken in this script.
- “Hundreds of miles above Earth” is a rounded, accurate description of Hubble's orbit.
