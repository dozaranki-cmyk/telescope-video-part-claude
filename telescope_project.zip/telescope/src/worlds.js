import * as THREE from 'three';
import {box, cyl, sign, ground, cloud, facade, lampPost} from './kit.js';
import {character} from './char.js';
import {wordT} from './camera.js';

const LOC = {launch:0, blur:220, investigate:440, mirror:660, science:880, orbit:1100, plan:1320, shuttle:1540, repair:1760, glasses:1980, comeback:2200, twist:2420};
const ink = '#351f22';
const mat = (c, rough=0.7) => new THREE.MeshToonMaterial({color:c, roughness:rough});
function outlinedBox(w,h,d,color,x,y,z,group,edge=0.045){
  const m = new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(color)); m.position.set(x,y,z); group.add(m);
  const e = new THREE.EdgesGeometry(m.geometry); const l = new THREE.LineSegments(e,new THREE.LineBasicMaterial({color:ink})); l.position.copy(m.position); group.add(l); return m;
}
function addStars(g,x,z=-55,count=90){
  const geo=new THREE.BufferGeometry(), a=[]; let seed=11; const r=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  for(let i=0;i<count;i++) a.push(x+(r()-.5)*95,8+r()*55,z-r()*35);
  geo.setAttribute('position',new THREE.Float32BufferAttribute(a,3)); const p=new THREE.Points(geo,new THREE.PointsMaterial({color:'#fff3c7',size:0.65,sizeAttenuation:true}));g.add(p);
}
function hubble(g,x,y=7,z=-8,scale=1){
  const h=new THREE.Group(); h.position.set(x,y,z); h.scale.setScalar(scale); g.add(h);
  const tube=new THREE.Mesh(new THREE.CylinderGeometry(1.05,1.15,5.4,16),mat('#d7dce0')); tube.rotation.z=Math.PI/2; h.add(tube);
  const front=new THREE.Mesh(new THREE.CylinderGeometry(1.08,1.08,.55,20),mat('#8b9ba7')); front.rotation.z=Math.PI/2; front.position.x=2.9; h.add(front);
  const rim=new THREE.Mesh(new THREE.TorusGeometry(.83,.13,10,24),mat('#f1d99a')); rim.position.x=3.2; rim.rotation.y=Math.PI/2; h.add(rim);
  for(const side of [-1,1]){
    const panel=outlinedBox(4.2,1.7,.12, '#245a9b',side*.2,0,side*2.1,h);
    panel.rotation.y=side*.08;
    for(let i=0;i<4;i++) outlinedBox(.035,1.6,.14,'#72a9d7',side*.2-1.55+i*1.03,0,side*2.17,h,.005);
  }
  for(let i=0;i<4;i++){const a=new THREE.Mesh(new THREE.SphereGeometry(.11,10,8),mat('#e9b95e'));a.position.set(-1.7+i*1.1,1.2,.4);h.add(a);}
  return h;
}
function room(g,x,color='#b9d9df'){
  outlinedBox(23,11,.5,color,x,5,-13,g); outlinedBox(23,.45,18,'#7b5b45',x,0,-4,g);
  for(let i=0;i<5;i++){outlinedBox(3.5,2.4,.22,'#314b63',x-9+i*4.5,7.5,-12.6,g);outlinedBox(3.1,2,.08,'#f2d18c',x-9+i*4.5,7.5,-12.4,g);}
  for(let i=0;i<4;i++) { outlinedBox(.25,4,.25,'#d4b17d',x-10+i*6.5,2,-7,g); }
}
function consoleDesk(g,x,z=0){
  outlinedBox(7,.5,2.2,'#8b573c',x,1.5,z,g); for(let dx of [-2.7,2.7]) outlinedBox(.25,1.5,.25,'#62412f',x+dx,.7,z,g);
  for(let i=0;i<3;i++){outlinedBox(1.35,.9,.12,['#347f9b','#a84e48','#4e8b66'][i],x-1.8+i*1.8,2.2,z-.8,g);}
}
export function buildWorld(){
 const G=new THREE.Group(), chars=[], anim=[];
 // Launch pad / Florida coast
 let x=LOC.launch; G.add(ground(90,90,'#8caa83',{x,z:0,seed:12,repeat:12}));
 for(let i=0;i<7;i++){outlinedBox(6,10+(i%3)*3,7,['#d2a77a','#b67e63','#c69a70'][i%3],x-25+i*8,5+(i%3)*1.5,-24,G);}
 const rocket=new THREE.Group(); rocket.position.set(x,0,-4);G.add(rocket);
 outlinedBox(4,18,4,'#e8e5dc',0,10,0,rocket); const nose=new THREE.Mesh(new THREE.ConeGeometry(2,4,16),mat('#e84b3c'));nose.position.y=21;rocket.add(nose);
 for(let s of [-1,1]) outlinedBox(1.4,7,1.6,'#df493c',s*2.3,3,0,rocket);
 outlinedBox(5,1,5,'#4a5969',0,0,0,rocket);
 for(let i=0;i<8;i++) {const flame=new THREE.Mesh(new THREE.ConeGeometry(.7,3,12),mat(i%2?'#ff9e36':'#ffe07a'));flame.position.set((i-3.5)*.45,-2.2,0);flame.rotation.z=Math.PI;rocket.add(flame);}
 for(let i=0;i<4;i++){outlinedBox(1.4,2.3,.3,'#e6d6aa',x-10+i*6,1.2,5,G);}
 const tech=character({palette:'engineer',hat:'cap',seed:2});tech.position.set(x+6,.05,5);G.add(tech);chars.push(tech);
 // Blurry control room
 x=LOC.blur; room(G,x,'#b4d7df'); consoleDesk(G,x+1,-1);
 const screen=sign('BLURRY FIRST LIGHT',5.5,2.6,{bg:'#16243d',fg:'#f6dfaa',font:'bold 68px Arial',sub:'1990'});screen.position.set(x-5,5,-11.9);G.add(screen);
 for(let i=0;i<4;i++){const c=character({palette:['student','clerk','official','teal'][i],seed:20+i});c.position.set(x-8+i*5,.05,3+i%2);G.add(c);chars.push(c);}
 // Investigation lab
 x=LOC.investigate; room(G,x,'#b5d5d3'); consoleDesk(G,x-2,0);
 for(let i=0;i<3;i++){outlinedBox(1.2,2.6,1.2,'#637b88',x+5+i*3,1.3,-1,G); outlinedBox(1.4,.25,1.4,'#e5c77f',x+5+i*3,2.8,-1,G);}
 const lab=character({palette:'engineer',hat:'bowler',glasses:true,seed:31});lab.position.set(x+1,.05,3);G.add(lab);chars.push(lab);
 const labSign=sign('CHECK THE OPTICS',4,1.2,{bg:'#e8d9b8',fg:'#3b3430',font:'bold 60px Arial'});labSign.position.set(x+7,5,-11.6);G.add(labSign);
 // Mirror chamber
 x=LOC.mirror; room(G,x,'#6c8297');
 const mirror=new THREE.Mesh(new THREE.SphereGeometry(4,48,24,0,Math.PI*2,0,Math.PI/2),new THREE.MeshStandardMaterial({color:'#a8c5d8',metalness:.9,roughness:.12,side:THREE.DoubleSide}));mirror.rotation.x=Math.PI;mirror.position.set(x,5,-3);G.add(mirror);
 const rim=new THREE.Mesh(new THREE.TorusGeometry(3.8,.16,12,48),mat('#e7c77d'));rim.position.set(x,5,-3);G.add(rim);
 const inspector=character({palette:'mustard',hat:'cap',seed:42});inspector.position.set(x-5,.05,3);G.add(inspector);chars.push(inspector);
 for(let i=0;i<5;i++){outlinedBox(.3,4,.3,'#b9c5cd',x-9+i*4,2,-9,G);}
 // Optical science demo, ray paths
 x=LOC.science; room(G,x,'#173b59');
 const mirror2=new THREE.Mesh(new THREE.SphereGeometry(3.4,40,20,0,Math.PI*2,0,Math.PI/2),mat('#c6dce9'));mirror2.rotation.x=Math.PI;mirror2.position.set(x-5,5,-4);G.add(mirror2);
 const focal=new THREE.Mesh(new THREE.SphereGeometry(.28,16,12),mat('#ffd95d'));focal.position.set(x+5,5,-4);G.add(focal);
 for(let i=0;i<7;i++){const pts=[new THREE.Vector3(x-8,2.5+i*.8,-3),new THREE.Vector3(x+5,5+(i-3)*.75,-3)];const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:i%2?'#ffce6c':'#7fe4ff',linewidth:2}));G.add(line);}
 const scienceChar=character({palette:'student',glasses:true,seed:51});scienceChar.position.set(x+8,.05,4);G.add(scienceChar);chars.push(scienceChar);
 // Orbit: Earth + Hubble tiny flaw
 x=LOC.orbit; const earth=new THREE.Mesh(new THREE.SphereGeometry(17,40,24),mat('#287eb1'));earth.position.set(x, -12,-28);G.add(earth);
 for(let i=0;i<15;i++){const c=new THREE.Mesh(new THREE.SphereGeometry(1.5+(i%3),12,8),mat('#63a87d'));c.position.set(x-13+(i*7)%28,-1-(i%4)*3,-13-(i%5)*3);G.add(c);}
 addStars(G,x,-65,120); const orb=hubble(G,x+1,14,-5,.85);
 const small=new THREE.Mesh(new THREE.SphereGeometry(.3,12,8),mat('#ff5c43'));small.position.set(x+4,14,-2);G.add(small);
 // Engineering plan workshop
 x=LOC.plan; room(G,x,'#a8d5d0'); consoleDesk(G,x,0);
 const device=outlinedBox(3.2,3.2,2.3,'#8e9ca8',x+6,3,-3,G); for(let i=0;i<4;i++){const m=new THREE.Mesh(new THREE.CircleGeometry(.38,24),mat('#f2d58b'));m.position.set(x+4.8+i*.8,3.3,-1.82);G.add(m);}
 const planner=character({palette:'engineer',hat:'bowler',seed:62});planner.position.set(x-5,.05,3);G.add(planner);chars.push(planner);
 const planSign=sign('CORRECT THE LIGHT',4.8,1.2,{bg:'#e7d8b9',fg:'#33495b',font:'bold 55px Arial'});planSign.position.set(x+5,7,-12);G.add(planSign);
 // Shuttle rendezvous
 x=LOC.shuttle; addStars(G,x,-60,110); const h2=hubble(G,x+9,13,-13,.72);
 const shuttle=new THREE.Group();shuttle.position.set(x-5,8,-3);G.add(shuttle);
 outlinedBox(12,2.2,3.4,'#e8e8e5',0,0,0,shuttle); const nose2=new THREE.Mesh(new THREE.ConeGeometry(1.5,4,16),mat('#e8e8e5'));nose2.rotation.z=-Math.PI/2;nose2.position.x=8;shuttle.add(nose2);
 for(let s of [-1,1]) outlinedBox(5,.25,2,'#b6c8d9',0,1.2,s*2,shuttle);
 const astro=character({palette:'official',hat:'none',seed:72,scale:1.5});astro.position.set(x-5,5,0);G.add(astro);chars.push(astro);
 // Repair bay
 x=LOC.repair; addStars(G,x,-45,80);hubble(G,x+1,8,-8,.92);
 const bay=outlinedBox(6,4,4,'#9aaab4',x-1,4,-1,G); const arm=new THREE.Group();arm.position.set(x-5,6,1);G.add(arm);
 for(let i=0;i<5;i++){outlinedBox(1.2,.25,.25,'#d5b56e',x-8+i*1.5,7,-1,G);}
 const repairAstro=character({palette:'official',hat:'none',seed:73,scale:1.6});repairAstro.position.set(x-5,4,2);G.add(repairAstro);chars.push(repairAstro);
 const repairSign=sign('COSTAR',3,1,{bg:'#e7d9b8',fg:'#30455c',font:'bold 70px Arial'});repairSign.position.set(x-1,13,-3);G.add(repairSign);
 // Corrective optics / giant glasses visual
 x=LOC.glasses; addStars(G,x,-60,80);hubble(G,x,8,-10,.75);
 const frame=new THREE.Group();frame.position.set(x+1,9,-2);G.add(frame);
 for(let s of [-1,1]){const ring=new THREE.Mesh(new THREE.TorusGeometry(2,.2,12,40),mat('#ffd46b'));ring.position.x=s*2.2;frame.add(ring);}
 const bridge=outlinedBox(.5,.25,.25,'#ffd46b',0,9,-2,G);bridge.position.set(x+1,9,-2);
 for(let i=0;i<6;i++){const ray=new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(x-8,4+i*1.1,-1),new THREE.Vector3(x+4,8,-1)]),new THREE.LineBasicMaterial({color:'#ffe18b'}));G.add(ray);}
 // Comeback galaxy gallery
 x=LOC.comeback; room(G,x,'#253b62');
 for(let i=0;i<5;i++){const panel=sign(i===0?'BEFORE':'AFTER',2.5,2,{bg:i===0?'#30354a':'#182b52',fg:'#fff0c8',font:'bold 62px Arial',sub:i===0?'BLUR':'SHARP'});panel.position.set(x-9+i*4.5,5,-11.5);G.add(panel);}
 for(let i=0;i<30;i++){const s=new THREE.Mesh(new THREE.SphereGeometry(.12+(i%4)*.06,8,8),mat(i%2?'#f7d47b':'#8bc9e8'));s.position.set(x-10+(i*7%21),2+(i*3%7),-8-(i%3));G.add(s);}
 const astronomer=character({palette:'teal',glasses:true,seed:82});astronomer.position.set(x+8,.05,3);G.add(astronomer);chars.push(astronomer);
 // Cosmic reveal / final Hubble glasses gag
 x=LOC.twist; addStars(G,x,-70,180);hubble(G,x,9,-8,1.05);
 const bigGlasses=new THREE.Group();bigGlasses.position.set(x+1,10,-4);G.add(bigGlasses);
 for(let s of [-1,1]){const ring=new THREE.Mesh(new THREE.TorusGeometry(2.2,.24,14,48),mat('#ffd45d'));ring.position.x=s*2.35;bigGlasses.add(ring);const shine=new THREE.Mesh(new THREE.SphereGeometry(.2,10,8),mat('#fff2c4'));shine.position.set(s*2.35+.7,.8,.1);bigGlasses.add(shine);}
 const bridge2=outlinedBox(.55,.25,.25,'#ffd45d',0,0,0,bigGlasses);bridge2.position.set(0,0,0);
 for(let i=0;i<12;i++){const c=cloud(x-24+i*4,22+(i%3)*5,-65,2.2,'#405f9b');G.add(c);}
 return {group:G,update(t,cam,shot){for(const c of chars)c.userData.update(t,cam.position);rocket.position.y=shot==='launch'?Math.max(0,(t-.3)*2.2):0;rocket.rotation.z=shot==='launch'?Math.sin(t*4)*.01:0;orb.rotation.y=t*.15;h2.rotation.y=t*.12;bigGlasses.rotation.y=Math.sin(t*1.4)*.12;frame.rotation.y=Math.sin(t)*.08;}};
}
