import * as THREE from 'three';
import timing from './timing.json';
const S=Object.fromEntries(timing.shots.map(s=>[s.key,s]));
const keys=timing.shots.map(s=>s.key);
export const CUTS=keys.map((k,i)=>i===0?0:(timing.shots[i-1].end+timing.shots[i].start)/2);
export const END=timing.duration;
export const wordT=(key,idx)=>S[key].start+(S[key].end-S[key].start)*idx/S[key].words;
export const LIGHTS={
 day:{sun:'#fff0cf',si:2.6,sky:'#a9d8ff',gnd:'#d9a878',hi:1.15,fog:'#cfe7f7',near:150,far:650,sunOff:[-50,90,60],shadow:85,top:'#3d8fe0',hor:'#cde9f8',pt:null},
 office:{sun:'#fff4e4',si:1.8,sky:'#c6e3f2',gnd:'#b48a62',hi:1.1,fog:'#c4dce7',near:35,far:130,sunOff:[-8,15,10],shadow:18,top:'#7fb7e6',hor:'#d6ecf6',pt:{c:'#ffc77a',i:5,p:[-2,4,1],d:20}},
 space:{sun:'#b8c9ff',si:1.3,sky:'#1a2856',gnd:'#11172b',hi:.55,fog:'#101a3a',near:80,far:420,sunOff:[-35,65,40],shadow:60,top:'#07132f',hor:'#182d5c',pt:null},
 lab:{sun:'#fff0d5',si:2.0,sky:'#a6d6e9',gnd:'#7c8d91',hi:1.1,fog:'#b7d5df',near:30,far:140,sunOff:[-8,15,10],shadow:20,top:'#6eaed5',hor:'#d7eff5',pt:{c:'#ffd58a',i:8,p:[0,5,2],d:18}},
 cosmic:{sun:'#d2dcff',si:1.0,sky:'#202b5a',gnd:'#11172b',hi:.65,fog:'#15204a',near:50,far:350,sunOff:[-25,45,30],shadow:45,top:'#091332',hor:'#273c70',pt:null}
};
const V=a=>new THREE.Vector3(...a);
const P={
 launch:{light:'day',anchor:[0,0,0],keys:[{p:[-8,15,27],l:[0,12,-3]},{p:[-3,13,22],l:[0,13,-3]},{p:[4,16,20],l:[0,18,-3]}]},
 blur:{light:'office',anchor:[220,0,0],keys:[{p:[208,5,15],l:[216,5,-10]},{p:[218,5,13],l:[220,5,-10]},{p:[225,4,12],l:[222,5,-10]}]},
 investigate:{light:'lab',anchor:[440,0,0],keys:[{p:[428,4,15],l:[438,4,-2]},{p:[440,5,12],l:[442,4,-3]},{p:[448,4,11],l:[447,5,-8]}]},
 mirror:{light:'lab',anchor:[660,0,0],keys:[{p:[649,7,13],l:[660,5,-3]},{p:[657,6,10],l:[660,5,-3]},{p:[664,5,8],l:[660,5,-3]}]},
 science:{light:'space',anchor:[880,0,0],keys:[{p:[868,8,13],l:[880,5,-4]},{p:[879,6,12],l:[883,5,-4]},{p:[887,5,10],l:[886,5,-4]}]},
 orbit:{light:'space',anchor:[1100,0,0],keys:[{p:[1087,15,25],l:[1100,5,-25]},{p:[1097,13,20],l:[1100,4,-25]},{p:[1107,12,17],l:[1102,8,-8]}]},
 plan:{light:'office',anchor:[1320,0,0],keys:[{p:[1308,5,14],l:[1320,4,-2]},{p:[1318,5,12],l:[1322,4,-3]},{p:[1327,4,11],l:[1326,5,-3]}]},
 shuttle:{light:'space',anchor:[1540,0,0],keys:[{p:[1527,13,22],l:[1542,9,-10]},{p:[1538,11,18],l:[1544,10,-10]},{p:[1548,10,16],l:[1549,12,-10]}]},
 repair:{light:'space',anchor:[1760,0,0],keys:[{p:[1748,9,15],l:[1760,8,-8]},{p:[1758,8,13],l:[1760,8,-8]},{p:[1767,7,11],l:[1762,8,-8]}]},
 glasses:{light:'cosmic',anchor:[1980,0,0],keys:[{p:[1968,9,16],l:[1981,9,-2]},{p:[1978,9,14],l:[1981,9,-2]},{p:[1988,8,12],l:[1981,9,-2]}]},
 comeback:{light:'cosmic',anchor:[2200,0,0],keys:[{p:[2188,7,14],l:[2200,5,-8]},{p:[2198,7,12],l:[2200,5,-8]},{p:[2208,6,10],l:[2202,5,-8]}]},
 twist:{light:'cosmic',anchor:[2420,0,0],keys:[{p:[2408,12,22],l:[2420,10,-8]},{p:[2418,11,18],l:[2420,10,-8]},{p:[2428,9,14],l:[2420,10,-8]}]}
};
function warp(T,t){if(t<=T[0])return 0;if(t>=T[T.length-1])return 1;let i=0;while(t>T[i+1])i++;const u=(t-T[i])/(T[i+1]-T[i]);const e=u*u*(3-2*u);return (i+e)/(T.length-1);}
const CURVES={};
keys.forEach((k,i)=>{const p=P[k],a=CUTS[i],b=i+1<keys.length?CUTS[i+1]:END;const curve=q=>new THREE.CatmullRomCurve3(q.map(v=>V(v)),false,'centripetal');CURVES[k]={p:curve(p.keys.map(q=>q.p)),l:curve(p.keys.map(q=>q.l)),a,b};});
export function shotAt(t){let i=0;while(i+1<CUTS.length&&t>=CUTS[i+1])i++;return keys[i];}
export function cameraAt(t){const key=shotAt(t),c=CURVES[key],u=warp([c.a,(c.a+c.b)/2,c.b],t);return {key,pos:c.p.getPointAt(u),look:c.l.getPointAt(u),plan:P[key],a:c.a,b:c.b};}
export function dipAt(t){let o=0;keys.forEach((k,i)=>{if(!i)return;const d=Math.abs(t-CUTS[i]);if(d<.2)o=Math.max(o,1-d/.2);});return o;}
