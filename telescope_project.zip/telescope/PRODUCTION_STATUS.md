# Production status — The Telescope That Needed Glasses

- Approved narration: 170 words, exact text in `SHOTS.txt` and `script.md`.
- Voice: B — bright female, energetic American-English delivery.
- Full narration generated in one continuous take with local eSpeak fallback; `voiceover.wav` is the synchronized master and `voiceover.mp3` is the compact listening copy.
- `src/timing.json` was regenerated from the full take using the kit's `prepare_voice.py`; word captions are driven from the shot timing data in `Full.jsx`.
- Target composition: 720x1280 at 30 fps (vertical 9:16), approximately 61 seconds.
- MP4 render: NOT completed in this environment. Remotion dependencies were incomplete and `npm install` did not finish; a render attempt timed out. Do not treat this package as a finished MP4.

To render on a machine with working network access and Node.js LTS:
1. Extract this project ZIP.
2. Run `npm install` in this folder.
3. Run `bash render.sh` (Mac/Linux) or `render.bat` (Windows).
4. The script renders the silent 3D video, then muxes `voiceover.wav` into `final.mp4`.
