# The Telescope That Needed Glasses — production project

This project is customized from the supplied 3d-story-shorts Remotion + Three.js template.

## What's included
- `src/worlds.js`: story-specific 3D scenes: shuttle launch, control room, optical lab, mirror, ray diagram, orbit, engineering workshop, Endeavour rendezvous, COSTAR installation, optics/glasses, image comparison, final cosmic gag.
- `src/camera.js`: 12 moving camera plans and location transitions.
- `src/timing.json`: provisional 12-shot caption timeline (will be recalculated from the approved final voice recording).
- `SHOTS.txt`: exact approved narration split by shot.
- `script.md`: storyboard, fact map, sources, and dramatization notes.
- `prepare_voice.py`, `render.sh`, `render.bat`: audio timing and render workflow.

## Voice sample approval required
Three short English-US synthetic voice samples are provided in the companion `voice_samples/` folder:
- A: warm male
- B: bright female
- C: deeper male

These samples are generated with eSpeak as a local fallback, not a premium neural TTS voice. Choose A, B, or C, or provide a WAV/MP3 narration recorded by a human / another TTS provider. After the voice is chosen, generate the complete narration in one take and run:

```bash
python3 prepare_voice.py RAW.wav SHOTS.txt .
```

This writes `voiceover.wav` and updates `src/timing.json` to match the audio. Then run `bash render.sh` (Mac/Linux) or `render.bat` (Windows). Requires Node.js LTS.

## Important
The current timing file is a provisional layout, not voice-synchronized. Do not treat the project as a finished MP4 until a full narration is supplied, timing is regenerated, and the final render is checked.
